create definer = root@localhost view view_problem_cars as
select `db_rent_cars`.`cars_statuses`.`car_id`    AS `car_id`,
       `db_rent_cars`.`cars_statuses`.`status_id` AS `status_id`,
       `db_rent_cars`.`statuses`.`id_status`      AS `id_status`,
       `db_rent_cars`.`statuses`.`status`         AS `status`
from (`db_rent_cars`.`cars_statuses`
         left join `db_rent_cars`.`statuses`
                   on (`db_rent_cars`.`cars_statuses`.`status_id` = `db_rent_cars`.`statuses`.`id_status`))
where `db_rent_cars`.`cars_statuses`.`status_id` <> '1'
order by `db_rent_cars`.`cars_statuses`.`car_id`;

