create definer = root@localhost view view_all_cars_characteristics as
select `db_rent_cars`.`cars`.`id_car`             AS `id_car`,
       `db_rent_cars`.`markas`.`marka`            AS `marka`,
       `db_rent_cars`.`models`.`model`            AS `model`,
       `db_rent_cars`.`horsepowers`.`horsepower`  AS `horsepower`,
       `db_rent_cars`.`colors`.`color`            AS `color`,
       `db_rent_cars`.`regs_numbers`.`reg_number` AS `reg_number`
from ((((((((`db_rent_cars`.`cars` join `db_rent_cars`.`markas`) join `db_rent_cars`.`models`) join `db_rent_cars`.`horsepowers`) join `db_rent_cars`.`colors`) join `db_rent_cars`.`regs_numbers`) join `db_rent_cars`.`cars_markas_models_horsepowers`) join `db_rent_cars`.`markas_models_horsepowers`)
         join `db_rent_cars`.`cars_colors`)
where `db_rent_cars`.`cars`.`id_car` = `db_rent_cars`.`regs_numbers`.`id_reg_number`
  and `db_rent_cars`.`cars`.`id_car` = `db_rent_cars`.`cars_markas_models_horsepowers`.`car_id`
  and `db_rent_cars`.`cars_markas_models_horsepowers`.`marka_model_horsepower_id` =
      `db_rent_cars`.`markas_models_horsepowers`.`id_marka_model_horsepower`
  and `db_rent_cars`.`markas_models_horsepowers`.`model_id` = `db_rent_cars`.`models`.`id_model`
  and `db_rent_cars`.`markas_models_horsepowers`.`marka_id` = `db_rent_cars`.`markas`.`id_marka`
  and `db_rent_cars`.`markas_models_horsepowers`.`horsepower_id` = `db_rent_cars`.`horsepowers`.`id_horsepower`
  and `db_rent_cars`.`cars`.`id_car` = `db_rent_cars`.`cars_colors`.`car_id`
  and `db_rent_cars`.`cars_colors`.`color_id` = `db_rent_cars`.`colors`.`id_color`
order by `db_rent_cars`.`cars`.`id_car`;

