create definer = root@localhost view view_not_order_cars as
select `db_rent_cars`.`cars`.`id_car` AS `id_car`, `db_rent_cars`.`orders`.`car_id` AS `car_id`
from (`db_rent_cars`.`cars`
         left join `db_rent_cars`.`orders` on (`db_rent_cars`.`cars`.`id_car` = `db_rent_cars`.`orders`.`car_id`))
where `db_rent_cars`.`orders`.`car_id` is null
order by `db_rent_cars`.`cars`.`id_car`;

