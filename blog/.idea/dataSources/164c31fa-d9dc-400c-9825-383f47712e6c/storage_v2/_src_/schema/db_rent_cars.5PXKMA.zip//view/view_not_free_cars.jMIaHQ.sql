create definer = root@localhost view view_not_free_cars as
select `db_rent_cars`.`orders`.`id_order`        AS `id_order`,
       `db_rent_cars`.`orders`.`car_id`          AS `car_id`,
       `db_rent_cars`.`orders_dates`.`order_id`  AS `order_id`,
       `db_rent_cars`.`orders_dates`.`free_date` AS `free_date`
from (`db_rent_cars`.`orders`
         left join `db_rent_cars`.`orders_dates`
                   on (`db_rent_cars`.`orders`.`id_order` = `db_rent_cars`.`orders_dates`.`order_id`))
where `db_rent_cars`.`orders_dates`.`free_date` like '0000-00-00';

