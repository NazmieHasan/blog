create definer = root@localhost view view_free_cars as
select `db_rent_cars`.`cars`.`id_car`             AS `id_car`,
       `db_rent_cars`.`cars_statuses`.`car_id`    AS `car_id`,
       `db_rent_cars`.`cars_statuses`.`status_id` AS `status_id`
from (`db_rent_cars`.`cars`
         left join `db_rent_cars`.`cars_statuses`
                   on (`db_rent_cars`.`cars`.`id_car` = `db_rent_cars`.`cars_statuses`.`car_id`))
where `db_rent_cars`.`cars_statuses`.`status_id` like '1'
having !(`db_rent_cars`.`cars`.`id_car` in (select `db_rent_cars`.`cars`.`id_car`
                                            from (`db_rent_cars`.`cars`
                                                     join (`db_rent_cars`.`orders` left join `db_rent_cars`.`orders_dates` on (
                                                    `db_rent_cars`.`orders`.`id_order` =
                                                    `db_rent_cars`.`orders_dates`.`order_id`))
                                                          on (`db_rent_cars`.`cars`.`id_car` = `db_rent_cars`.`orders`.`car_id`))
                                            where `db_rent_cars`.`orders_dates`.`free_date` like '0000-00-00'));

