create definer = root@localhost view view_users_without_order as
select `db_rent_cars`.`accounts`.`id_user` AS `id_user`, `db_rent_cars`.`accounts`.`email` AS `email`
from (`db_rent_cars`.`accounts`
         left join `db_rent_cars`.`orders` on (`db_rent_cars`.`accounts`.`id_user` = `db_rent_cars`.`orders`.`user_id`))
where `db_rent_cars`.`orders`.`user_id` is null;

